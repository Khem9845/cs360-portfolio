package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);

        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        TextView linkRegister = findViewById(R.id.linkRegister);

        buttonLogin.setOnClickListener(v -> {
            String u = editUsername.getText().toString().trim();
            String p = editPassword.getText().toString().trim();

            if (db.validateLogin(u, p)) {
                startActivity(new Intent(this, InventoryActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid login. Register first.", Toast.LENGTH_SHORT).show();
            }
        });

        linkRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class))
        );
    }
}
