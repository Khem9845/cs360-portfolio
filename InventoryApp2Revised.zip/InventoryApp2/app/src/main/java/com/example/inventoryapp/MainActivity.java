package com.example.inventoryapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvInventory;
    private DatabaseHelper db;
    private ArrayList<InventoryItem> itemList;
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvInventory = findViewById(R.id.rvInventory);

        // Grid with 2 columns
        rvInventory.setLayoutManager(new GridLayoutManager(this, 2));
        rvInventory.setHasFixedSize(true);

        db = new DatabaseHelper(this);
        itemList = new ArrayList<>();

        // ✅ Correct adapter usage (List first + click listener)
        adapter = new ItemAdapter(itemList, item ->
                EditItemActivity.start(this, item.getId(), item.getName(), item.getQuantity())
        );

        rvInventory.setAdapter(adapter);

        loadInventory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventory(); // refresh after add/edit
    }

    private void loadInventory() {
        itemList.clear();
        itemList.addAll(db.getAllItems()); // ✅ correct method name
        adapter.notifyDataSetChanged();
    }
}