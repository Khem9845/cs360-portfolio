package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 1;

    // -------------------------
    // Items table
    // -------------------------
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_QTY = "quantity";

    // -------------------------
    // Users table (Login/Register)
    // -------------------------
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "user_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create items table
        String createItems = "CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT NOT NULL, " +
                COL_QTY + " INTEGER NOT NULL)";
        db.execSQL(createItems);

        // Create users table
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                COL_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsers);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop both tables and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // =========================================================
    // ITEMS (Inventory) CRUD
    // =========================================================

    public long addItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_QTY, quantity);

        long id = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return id;
    }

    public int updateItem(long id, String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_QTY, quantity);

        int rows = db.update(TABLE_ITEMS, values, COL_ID + "=?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(TABLE_ITEMS, COL_ID + "=?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public ArrayList<InventoryItem> getAllItems() {
        ArrayList<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT " + COL_ID + ", " + COL_NAME + ", " + COL_QTY +
                        " FROM " + TABLE_ITEMS +
                        " ORDER BY " + COL_ID + " DESC",
                null
        );

        if (c != null && c.moveToFirst()) {
            do {
                long id = c.getLong(0);
                String name = c.getString(1);
                int qty = c.getInt(2);
                list.add(new InventoryItem(id, name, qty));
            } while (c.moveToNext());
        }

        if (c != null) c.close();
        db.close();
        return list;
    }

    // =========================================================
    // USERS (Login/Register)
    // =========================================================

    public boolean registerUser(String username, String password) {
        if (username == null || username.trim().isEmpty()) return false;
        if (password == null || password.trim().isEmpty()) return false;

        // optional: block duplicates
        if (userExists(username.trim())) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username.trim());
        values.put(COL_PASSWORD, password); // (plain text for class project)

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    public boolean validateLogin(String username, String password) {
        if (username == null || password == null) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT " + COL_USER_ID + " FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username.trim(), password}
        );

        boolean valid = (c != null && c.moveToFirst());

        if (c != null) c.close();
        db.close();

        return valid;
    }

    public boolean userExists(String username) {
        if (username == null) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT " + COL_USER_ID + " FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME + "=?",
                new String[]{username.trim()}
        );

        boolean exists = (c != null && c.moveToFirst());

        if (c != null) c.close();
        db.close();

        return exists;
    }
}