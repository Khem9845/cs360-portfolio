package com.example.inventoryapp;

public class InventoryItem {

    private long id;   // 🔥 changed from int to long
    private String name;
    private int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}