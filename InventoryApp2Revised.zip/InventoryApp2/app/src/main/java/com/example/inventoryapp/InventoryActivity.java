package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private static final int REQ_SMS = 100;

    private DatabaseHelper db;
    private ArrayList<InventoryItem> items;
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        RecyclerView recycler = findViewById(R.id.recyclerItems);
        Button buttonAdd = findViewById(R.id.buttonAddItem);
        Button buttonSms = findViewById(R.id.buttonRequestSms);

        items = new ArrayList<>();
        adapter = new ItemAdapter(items, item ->
                EditItemActivity.start(this, item.getId(), item.getName(), item.getQuantity())
        );

        recycler.setLayoutManager(new GridLayoutManager(this, 2));
        recycler.setAdapter(adapter);

        buttonAdd.setOnClickListener(v ->
                EditItemActivity.start(this, -1, "", 0)
        );

        buttonSms.setOnClickListener(v -> requestSmsPermission());

        loadItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void loadItems() {
        items.clear();
        items.addAll(db.getAllItems());
        adapter.notifyDataSetChanged();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQ_SMS
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_SMS) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            Toast.makeText(
                    this,
                    granted ? "SMS permission granted." : "SMS permission denied.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}