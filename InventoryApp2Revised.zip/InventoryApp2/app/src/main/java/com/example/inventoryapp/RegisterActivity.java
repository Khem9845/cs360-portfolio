package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DatabaseHelper(this);

        EditText editNewUsername = findViewById(R.id.editNewUsername);
        EditText editNewPassword = findViewById(R.id.editNewPassword);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        TextView linkBackToLogin = findViewById(R.id.linkBackToLogin);

        buttonCreateAccount.setOnClickListener(v -> {
            String u = editNewUsername.getText().toString().trim();
            String p = editNewPassword.getText().toString().trim();

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Username and password required.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = db.registerUser(u, p);
            Toast.makeText(this, ok ? "Account created. Go log in." : "Username already exists.", Toast.LENGTH_SHORT).show();
            if (ok) finish();
        });

        linkBackToLogin.setOnClickListener(v -> finish());
    }
}
