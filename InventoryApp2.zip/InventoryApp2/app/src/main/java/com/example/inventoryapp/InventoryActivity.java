package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private final ArrayList<InventoryItem> items = new ArrayList<>();
    private ItemAdapter adapter;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                Toast.makeText(this,
                        granted ? "SMS permission granted." : "SMS permission denied (app still works).",
                        Toast.LENGTH_LONG).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        RecyclerView recycler = findViewById(R.id.recyclerItems);
        Button buttonAdd = findViewById(R.id.buttonAddItem);
        Button buttonSms = findViewById(R.id.buttonRequestSms);

        recycler.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new ItemAdapter(items, item ->
                EditItemActivity.start(this, item.id, item.name, item.quantity)
        );
        recycler.setAdapter(adapter);

        buttonAdd.setOnClickListener(v -> EditItemActivity.start(this, -1, "", 0));
        buttonSms.setOnClickListener(v -> requestSmsPermission());

        loadItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void loadItems() {
        items.clear();
        Cursor c = db.getAllItems();
        while (c.moveToNext()) {
            long id = c.getLong(0);
            String name = c.getString(1);
            int qty = c.getInt(2);
            items.add(new InventoryItem(id, name, qty));
        }
        c.close();
        adapter.notifyDataSetChanged();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }
}
