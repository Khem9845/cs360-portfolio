package com.example.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class EditItemActivity extends AppCompatActivity {

    private static final String EXTRA_ID = "id";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_QTY = "qty";

    private DatabaseHelper db;

    private EditText editItemName, editItemQty, editPhoneNumber, editLowThreshold;
    private Button buttonSave, buttonDelete;

    private long itemId;

    public static void start(Context ctx, long id, String name, int qty) {
        Intent i = new Intent(ctx, EditItemActivity.class);
        i.putExtra(EXTRA_ID, id);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_QTY, qty);
        ctx.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        db = new DatabaseHelper(this);

        editItemName = findViewById(R.id.editItemName);
        editItemQty = findViewById(R.id.editItemQty);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editLowThreshold = findViewById(R.id.editLowThreshold);
        buttonSave = findViewById(R.id.buttonSave);
        buttonDelete = findViewById(R.id.buttonDelete);

        itemId = getIntent().getLongExtra(EXTRA_ID, -1);
        String name = getIntent().getStringExtra(EXTRA_NAME);
        int qty = getIntent().getIntExtra(EXTRA_QTY, 0);

        if (name != null) editItemName.setText(name);
        editItemQty.setText(String.valueOf(qty));
        editLowThreshold.setText("5");

        if (itemId <= 0) {
            buttonDelete.setEnabled(false);
            buttonDelete.setAlpha(0.4f);
        }

        buttonSave.setOnClickListener(v -> saveItem());

        buttonDelete.setOnClickListener(v -> {
            if (itemId > 0) {
                boolean ok = db.deleteItem(itemId);
                Toast.makeText(this, ok ? "Item deleted." : "Delete failed.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void saveItem() {
        String name = editItemName.getText().toString().trim();
        String qtyStr = editItemQty.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Item name required.", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (Exception e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok;
        if (itemId <= 0) {
            long newId = db.addItem(name, qty);
            ok = newId != -1;
            if (ok) itemId = newId;
        } else {
            ok = db.updateItem(itemId, name, qty);
        }

        if (!ok) {
            Toast.makeText(this, "Save failed.", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Saved.", Toast.LENGTH_SHORT).show();
        maybeSendLowInventorySms(name, qty);
        finish();
    }

    private void maybeSendLowInventorySms(String itemName, int qty) {
        int threshold = 5;
        try { threshold = Integer.parseInt(editLowThreshold.getText().toString().trim()); }
        catch (Exception ignored) { }

        if (qty > threshold) return;

        String phone = editPhoneNumber.getText().toString().trim();
        if (phone.isEmpty()) return;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Low inventory, but SMS permission not granted.", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            String message = "Low inventory alert: " + itemName + " is low (Qty: " + qty + ").";
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
