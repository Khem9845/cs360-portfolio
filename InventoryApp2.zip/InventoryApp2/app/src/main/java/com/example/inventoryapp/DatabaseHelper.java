package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 1;

    // Users table
    private static final String T_USERS = "users";
    private static final String C_USER_ID = "id";
    private static final String C_USERNAME = "username";
    private static final String C_PASSWORD = "password";

    // Items table
    private static final String T_ITEMS = "items";
    private static final String C_ITEM_ID = "id";
    private static final String C_ITEM_NAME = "name";
    private static final String C_ITEM_QTY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers =
                "CREATE TABLE " + T_USERS + " (" +
                        C_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        C_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        C_PASSWORD + " TEXT NOT NULL" +
                        ");";

        String createItems =
                "CREATE TABLE " + T_ITEMS + " (" +
                        C_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        C_ITEM_NAME + " TEXT NOT NULL, " +
                        C_ITEM_QTY + " INTEGER NOT NULL" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createItems);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        onCreate(db);
    }

    // Register user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_USERNAME, username);
        cv.put(C_PASSWORD, password);
        long result = db.insert(T_USERS, null, cv);
        return result != -1;
    }

    // Validate login
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " + T_USERS + " WHERE username=? AND password=?",
                new String[]{username, password}
        );
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // Add item
    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_ITEM_NAME, name);
        cv.put(C_ITEM_QTY, qty);
        return db.insert(T_ITEMS, null, cv);
    }

    // Get all items
    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + T_ITEMS, null);
    }

    // Update item
    public boolean updateItem(long id, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_ITEM_NAME, name);
        cv.put(C_ITEM_QTY, qty);
        int rows = db.update(T_ITEMS, cv, "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // Delete item
    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(T_ITEMS, "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}
